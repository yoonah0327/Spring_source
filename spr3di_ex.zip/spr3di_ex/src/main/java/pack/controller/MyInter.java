package pack.controller;

public interface MyInter { //여러개의 요청서비스
	void inputData(); //입력따로
	void showData(); // 출력따로 
	
}
