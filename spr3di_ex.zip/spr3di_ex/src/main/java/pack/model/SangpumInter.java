package pack.model;

public interface SangpumInter {
	// 보통 여러개의 파생클래스가 있다. 수업시간에는 간단히 한개만.
	int calcMoney(String sang, int su, int dan);
	
}
