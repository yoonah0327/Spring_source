package pack.controller;

public interface MyInter {
	void inputMoney();
	void showResult();
}
