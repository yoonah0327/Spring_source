package pack.model;

public interface MoneyInter {
	int[] calcMoney(int money);
	//.. 다양한 추상메소드가 있을 수 있다. 
}
