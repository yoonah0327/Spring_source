package pack.model;

import java.util.List;

public interface DataInterface {
	List<MemDto> selectDataAll();
}
